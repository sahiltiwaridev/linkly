import { useNavigation } from "@react-navigation/native";
import { View, Text, Pressable } from "react-native";
import SettingsIcon from "../../assets/icons/settings.svg";
import ScannerIcon from "../../assets/icons/qr-scan.svg";
import NextIcon from "../../assets/icons/next.svg";
import QRIcon from "../../assets/icons/qr.svg";
import ConnectingIcon from "../../assets/icons/connecting.svg";
import PrimaryCard from "../../components/cards/PrimaryCard";

export default function HomeScreen() {
  const navigation = useNavigation<any>();
  return (
    <View className="p-5 h-full justify-between items-center">
      <View className="w-full flex-row items-center justify-between">
        <View className="flex-row items-center justify-between gap-3">
          <QRIcon width={24} height={24} fill={"#4f8cff"} />
          <Text className="text-white font-bold text-2xl">Linkly</Text>
        </View>
        <Pressable
          onPress={() => {
            navigation.navigate("SettingsScreen");
          }}
        >
          <SettingsIcon width={24} height={24} fill={"#ffffff"} />
        </Pressable>
      </View>
      <View className="justify-center items-center gap-10">
        <View className="h-56 w-56 justify-center items-center">
          <View className="absolute h-60 w-60 rounded-full border border-[#4f8cff]/25" />
          <View className="absolute h-48 w-48 rounded-full border border-[#4f8cff]/50" />
          <View className="absolute h-36 w-36 rounded-full border border-[#4f8cff]/75" />
          <ConnectingIcon width={72} height={72} fill="#4f8cff" />
        </View>
        <View className="justify-center items-center gap-1">
          <Text className="text-white">Ready to Connect?</Text>
          <Text className="text-[#B3B3B3]">
            Share your digital profile instantly.
          </Text>
        </View>
      </View>
      <View className="w-full gap-4">
        <Pressable
          className="bg-[#4f8cff] py-5 px-3 flex-row items-center justify-between rounded-xl"
          onPress={() => {
            navigation.navigate("ScanQRScreen");
          }}
        >
          <View className="flex-row items-center gap-3">
            <ScannerIcon width={32} height={32} fill={"#ffffff"} />
            <View>
              <Text className="text-white text-xl font-semibold">Scan QR</Text>
              <Text className="text-white">Connect with new people</Text>
            </View>
          </View>
          <NextIcon width={32} height={32} fill={"#ffffff"} />
        </Pressable>
        <View className="flex-row justify-between items-center gap-3">
          <PrimaryCard
            icon={QRIcon}
            text="My QR"
            onPress={() => {
              navigation.navigate("MyQRScreen");
            }}
          />
          <PrimaryCard
            icon={QRIcon}
            text="Saved"
            onPress={() => {
              navigation.navigate("SavedProfilesScreen");
            }}
          />
        </View>
      </View>
    </View>
  );
}
